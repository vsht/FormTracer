(* Wolfram Language Init File *)

Get[ "FormTracer`FormTracer`"]